﻿//114.Rocio (...)

class PruebaDeRecuadro
{
    static void Main()
    {   
        Recuadro prueba = new Recuadro(1, 4, 8, 10, 'x');
        prueba.Dibujar();
        
        Recuadro prueba2 = new Recuadro(20, 10, 20, 5, '+');
        prueba2.Dibujar();

        RecuadroRelleno prueba3 = new RecuadroRelleno(18, 12, 8, 8, '-');
        prueba3.Dibujar();

        Recuadro prueba4 = new Recuadro(2, 3);
        prueba4.Dibujar();


    }
}

