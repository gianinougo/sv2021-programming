﻿// Rocio (...)
//114. Crea un segundo constructor en la clase Recuadro, que permita indicar
//sólo la posición de inicio, y tome por defecto los valores: ancho = 40, alto
//= 10, carácter = *. Pruébalo desde "Main".

using System;
class Recuadro
{ 
    protected int x, y, ancho, alto;
    protected char caracter;
    
    public int GetX() { return x; }
    public int GetY() { return y; }
    public int GetAncho() { return ancho; }
    public int GetAlto() { return alto; }
    public char GetCaracter() { return caracter; }
    
    public void SetX(int nuevoX) { x = nuevoX; }
    public void SetY(int nuevoY) { y = nuevoY; }
    public void SetAncho(int nuevoAncho) { ancho = nuevoAncho; }
    public void SetAlto(int nuevoAlto) { alto = nuevoAlto; }
    public void SetCaracter(char nuevoCaracter) { caracter = nuevoCaracter; }

    public Recuadro(){ }

    public Recuadro(int valorX, int valorY) 
    {
        x = valorX;
        y = valorY;
        ancho = 40;
        alto = 10;
        caracter = '*';
    }

    public  Recuadro (int valorX, int valorY, int valorAncho, int valorAlto,char valorCaracter) 
    {
        x =valorX;
        y = valorY;
        ancho = valorAncho;
        alto = valorAlto;
        caracter = valorCaracter;
    }

    public void Dibujar()
    {
        for (int fila=y; fila<=y+alto-1; fila++)
        {
            for (int col=x; col<=x+ancho-1; col++)
            {
                if ((fila==y)||(fila==y+alto-1) 
                    || (col==x)||(col==x+ancho-1))
                {
                    Console.SetCursorPosition(col, fila);
                    Console.Write(caracter);
                }
            }
        }
    }
}
