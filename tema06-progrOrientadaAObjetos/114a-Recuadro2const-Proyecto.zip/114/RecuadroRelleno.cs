﻿// Rocio (...)
//114. Crea un segundo constructor en la clase Recuadro, que permita indicar
//sólo la posición de inicio, y tome por defecto los valores: ancho = 40, alto
//= 10, carácter = *. Pruébalo desde "Main".

using System;

class RecuadroRelleno : Recuadro
{
    public RecuadroRelleno(int valorX, int valorY, int valorAncho, int valorAlto, char valorCaracter)
    {
        x = valorX;
        y = valorY;
        ancho = valorAncho;
        alto = valorAlto;
        caracter = valorCaracter;
    }

    public new void Dibujar()
    {
      
        for (int fila = y; fila <= y + alto - 1; fila++)
        {
            for (int col = x; col <= x + ancho - 1; col++)
            {
                Console.SetCursorPosition(col, fila);
                Console.Write(caracter);
            }
                Console.WriteLine();
            }
        }
    }