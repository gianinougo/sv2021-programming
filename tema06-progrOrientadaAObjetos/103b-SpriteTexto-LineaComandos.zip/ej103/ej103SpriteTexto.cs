//Author: Franco (...)
/*
103. Crea una nueva versión del ejercicio 102, en la que 
cada clase esté en un fichero independiente, empleando 
Visual Studio (o alguna herramienta similar). Deberás 
entregar todo el proyecto de Visual Studio, comprimido en 
un fichero ZIP.
*/

using System;

class SpriteTexto {

    int x;
    int y;
    char caracter;

    public void SetX(int nuevoValor) {
        x = nuevoValor;
    }

    public void SetY(int nuevoValor) {
        y = nuevoValor;
    }

    public void SetCaracter(char nuevoValor) {
        caracter = nuevoValor;
    }

    public void Dibujar() {
        Console.SetCursorPosition(x, y);
        Console.Write(caracter);
    }

    public void MoverDerecha() {
        x++;
    }

    public void MoverIzquierda() {
        x--;
    }

}
