//Author: Franco (...)
/*
103. Crea una nueva versión del ejercicio 102, en la que 
cada clase esté en un fichero independiente, empleando 
Visual Studio (o alguna herramienta similar). Deberás 
entregar todo el proyecto de Visual Studio, comprimido en 
un fichero ZIP.
*/

using System;

class PruebaDeSprite {

    static void Main() {

        SpriteTexto st = new SpriteTexto();

        st.SetX(40);
        st.SetY(12);
        st.SetCaracter('A');

        st.Dibujar();
        
        st.MoverDerecha();

        st.Dibujar();

    }

}
