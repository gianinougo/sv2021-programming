#!/bin/bash

mcs ej103Main.cs ej103SpriteTexto.cs -out:ej103.exe && mono ej103.exe