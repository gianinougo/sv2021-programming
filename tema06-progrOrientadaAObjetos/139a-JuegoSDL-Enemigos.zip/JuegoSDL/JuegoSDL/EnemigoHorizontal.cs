﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoSDL
{
    class EnemigoHorizontal : Enemigo
    {
        public EnemigoHorizontal()
            : base("datos/enemigo.png")
        {
            velocX = 5;
            ancho = 54;
            alto = 63;
        }

        public override void Mover()
        {
            x += velocX;
            if ((x >= 1100) // !!!!
                    || (x <= 100))  // !!!!
                velocX = -velocX;
        }

    }
}
