﻿// Javier (...)

class Pared : Sprite
{
    private int tamanyo;

    public Pared() { }
    public int GetTamanyo() { }
    public void SetTamanyo(int tamanyo) { }
}
