﻿// Javier (...)

class Laberinto
{
    protected string nombre;
    protected Pared[] muros;
    protected Galleta[] galletas;
    protected GalletaPoder[] galletasPoder;

    public Laberinto() { }
    public int GetNombre() { }
    public void SetNombre(string nombre) { }
    public void Dibujar() { }
}

