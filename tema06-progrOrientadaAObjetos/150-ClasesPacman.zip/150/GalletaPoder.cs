﻿// Javier (...)

class GalletaPoder : Galleta
{
}
