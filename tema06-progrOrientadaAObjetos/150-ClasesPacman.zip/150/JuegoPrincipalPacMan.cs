﻿// Ejercicio recomendado 150
// Javier (...)

class JuegoPrincipalPacMan
{
    public static void Main()
    {
        Partida p = new Partida();
        p.Lanzar();
    }
}
