﻿// Javier (...)

class Galleta : Sprite
{

}
