﻿// Javier (...)

class Partida
{
    private Laberinto[] laberintos;
    private Fantasma[] fantasmas;
    private JuegoPrincipalPacMan pacman;

    public Partida() { }
    public void Lanzar() { }
}
