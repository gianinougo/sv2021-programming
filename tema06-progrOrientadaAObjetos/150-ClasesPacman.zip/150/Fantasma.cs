﻿// Javier (...)

class Fantasma : Sprite
{
}

