﻿// Javier (...)

class Pac_Man : Sprite
{
    private bool efectoGalletaPoder;

    public Pac_Man() { }

    public bool GetEfectoGalletaPoder() { }
    public void SetEfectoGalletaPoder(bool efectoGP) { }
    public override void Mover()
    {
        base.Mover();
    }
    public override void MoverA(int x, int y)
    {
        base.MoverA(x, y);
    }

    public override void Dibujar()
    {
        base.Dibujar();
    }

    public bool ComerGalletaPoder() { }
    public void ComerGalleta() { }

}
