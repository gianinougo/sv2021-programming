﻿// Ejercicio recomendado 115
// Javier (...)

using System;

class PruebaDeSprite
{
    static void Main()
    {
        SpriteTexto s = new SpriteTexto();

        s.SetX(40);
        s.SetY(12);
        s.SetCaracter('A');
        s.Dibujar();
        
        Console.ReadLine();
        s.MoverDerecha();
        s.Dibujar();
        
        Console.ReadLine();
        s.MoverDerecha();
        s.Dibujar();
        
        Console.ReadLine();
        s.MoverDerecha();
        s.Dibujar();
        
        Console.ReadLine();
        SpriteTexto s2 = new SpriteTexto(2, 20, '#');
        s2.Dibujar();

        Console.ReadLine();
    }
}
