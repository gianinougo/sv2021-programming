﻿// Ejercicio recomendado 117
// Javier (...)

using System;

class PruebaDeSprite
{
    static void Main()
    {
        NaveJugador jugador = new NaveJugador();
        NaveEnemiga enemigo = new NaveEnemiga();

        jugador.SetX(5);
        jugador.SetY(10);
        jugador.Dibujar();

        enemigo.SetX(10);
        enemigo.Dibujar();

        while (true)
        {
            ConsoleKeyInfo tecla = Console.ReadKey();
            Console.Clear();

            if (tecla.Key == ConsoleKey.LeftArrow)
                jugador.MoverIzquierda();
            else if (tecla.Key == ConsoleKey.RightArrow)
                jugador.MoverDerecha();

            jugador.Dibujar();
            enemigo.Dibujar();
        }
    }
}
