﻿// Ejercicio recomendado 117
// Javier (...)

using System;

class NaveEnemiga : SpriteTextoColor
{
    public NaveEnemiga()
    {
        color = "cyan";
        caracter = 'W';
    }
}

