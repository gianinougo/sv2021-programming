﻿// Ejercicio recomendado 117
// Javier (...)

using System;

class SpriteTextoColor : SpriteTexto
{
    protected string color;

    public SpriteTextoColor()
    {

    }

    public SpriteTextoColor(int nuevoX, int nuevoY, char nuevoCaracter, 
        string nuevoColor)
    {
        x = nuevoX;
        y = nuevoY;
        caracter = nuevoCaracter;
        color = nuevoColor;
    }

    public new void Dibujar()
    {
        switch (color)
        {
            case "blanco": Console.ForegroundColor = ConsoleColor.White; break;
            case "cyan": Console.ForegroundColor = ConsoleColor.Cyan; break;
            case "amarillo": Console.ForegroundColor = ConsoleColor.Yellow; break;            
        }

        Console.SetCursorPosition(x, y);
        Console.Write(caracter);
        Console.ResetColor();
    }
}