﻿// Ejercicio recomendado 117
// Javier (...)


class NaveJugador : SpriteTextoColor
{
    public NaveJugador()
    {
        color = "amarillo";
        caracter = 'A';
    }
}
