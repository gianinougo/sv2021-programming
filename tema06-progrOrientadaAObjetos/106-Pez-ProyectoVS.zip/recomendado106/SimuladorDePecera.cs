﻿//Recomendado 106, clase Pez, por Ezequiel (...) 1º DAM

using System;

class SimuladorDePecera
{
    static void Main()
    {
        Pez dorada = new Pez();

        dorada.SetNombre("goldeen");
        dorada.SetEspecie("dorada");

        dorada.Nadar();
    }
}
