﻿//Rocio (...), retoques por Nacho

class PruebaDeRecuadro
{
    static void Main()
    {
        Recuadro prueba = new Recuadro();
        prueba.SetX(20);
        prueba.SetY(4);
        prueba.SetAncho(8);
        prueba.SetAlto(10);
        prueba.SetCaracter('*');
        prueba.Dibujar();
        
        Recuadro prueba2 = new Recuadro();
        prueba2.SetX(2);
        prueba2.SetY(10);
        prueba2.SetAncho(20);
        prueba2.SetAlto(5);
        prueba2.SetCaracter('+');
        prueba2.Dibujar();
    }
}

