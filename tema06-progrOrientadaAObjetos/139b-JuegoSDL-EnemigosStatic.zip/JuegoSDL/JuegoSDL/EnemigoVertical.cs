﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoSDL
{
    class EnemigoVertical : Enemigo
    {
        public EnemigoVertical()
            : base("datos/objetoCae.png")
        {
            velocY = 3;
            ancho = 72;
            alto = 27;
        }

        public override void Mover()
        {
            y += velocY;
            if (y >= 700)
                y = -10;
        }
    }
}
