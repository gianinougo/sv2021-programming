﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoSDL
{
    class Enemigo : Sprite
    {
        public Enemigo(string nombre) : base (nombre)
        {
        }

        public virtual void Mover()
        {
            // Para ser redefinido en cada clase hija
        }
    }
}
