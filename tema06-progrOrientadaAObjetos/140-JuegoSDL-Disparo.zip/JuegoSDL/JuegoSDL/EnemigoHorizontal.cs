﻿namespace JuegoSDL
{
    class EnemigoHorizontal : Enemigo
    {
        private static int velocidadLateral = 5;

        public EnemigoHorizontal()
            : base("datos/enemigo.png")
        {
            ancho = 54;
            alto = 63;
        }

        public override void Mover()
        {
            x += velocidadLateral;
            if ((x >= 1100) // !!!!
                    || (x <= 100))  // !!!!
                velocidadLateral = -velocidadLateral;
        }

    }
}
