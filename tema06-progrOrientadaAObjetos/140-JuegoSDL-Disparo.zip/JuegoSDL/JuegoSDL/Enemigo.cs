﻿namespace JuegoSDL
{
    class Enemigo : Sprite
    {
        public Enemigo(string nombre) : base (nombre)
        {
        }

        public override void Mover()
        {
            // Para ser redefinido en cada clase hija
        }
    }
}
