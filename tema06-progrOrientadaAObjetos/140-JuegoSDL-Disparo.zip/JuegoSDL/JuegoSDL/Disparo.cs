﻿namespace JuegoSDL
{
    class Disparo : Sprite
    {
        public Disparo()
            : base("datos/disparoEnemigo.png")
        {
            velocY = -4;
            ancho = 48;
            alto = 24;
            activo = false;
        }

        public void Aparecer(int x, int y)
        {
            this.x = x;
            this.y = y;
            activo = true;
        }

        public override void Mover()
        {
            if (!activo) return;

            y += velocY;
            if (y <= 0)
                activo = false;
        }
    }
}
