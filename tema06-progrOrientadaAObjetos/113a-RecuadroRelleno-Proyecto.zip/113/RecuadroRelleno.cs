﻿// Rocio (...)
//113. Crea una clase RecuadroRelleno, que herede de Recuadro,
//y cuyo método "Dibujar" muestre un rectángulo relleno, en vez de un formado
//sólo por bordes. Quizá eso te obligue a crear un constructor vacío en la
//clase Recuadro.

using System;

class RecuadroRelleno : Recuadro
{
    public RecuadroRelleno(int valorX, int valorY, 
        int valorAncho, int valorAlto, char valorCaracter)
    {
        x = valorX;
        y = valorY;
        ancho = valorAncho;
        alto = valorAlto;
        caracter = valorCaracter;
    }
    public new void Dibujar()
    {
      
        for (int fila = y; fila <= y + alto - 1; fila++)
        {
            for (int col = x; col <= x + ancho - 1; col++)
            {
                Console.SetCursorPosition(col, fila);
                Console.Write(caracter);
            }
            Console.WriteLine();
        }
    }
}