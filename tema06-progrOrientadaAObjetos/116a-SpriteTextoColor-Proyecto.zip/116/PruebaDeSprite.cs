﻿// Ejercicio recomendado 116
// Javier (...)

using System;

class PruebaDeSprite
{
    static void Main()
    {
        SpriteTexto s = new SpriteTexto();
        s.SetX(40);
        s.SetY(12);
        s.SetCaracter('A');
        s.Dibujar();
        
        SpriteTexto s2 = new SpriteTexto(2, 20, '#');
        s2.Dibujar();

        SpriteTextoColor s3 = new SpriteTextoColor(30, 8, 'X', "amarillo");
        s3.Dibujar();
    }
}
