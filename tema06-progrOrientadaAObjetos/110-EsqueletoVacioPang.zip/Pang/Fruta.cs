﻿
class Fruta
{
    public void SubirPuntuacion()
    {

    }
}

