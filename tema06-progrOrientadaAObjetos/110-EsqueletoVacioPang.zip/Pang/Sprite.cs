﻿
class Sprite
{
    public int X, Y;
    public int Imagen;

    public void Dibujar()
    {

    }

    public void Mover()
    {

    }
}

