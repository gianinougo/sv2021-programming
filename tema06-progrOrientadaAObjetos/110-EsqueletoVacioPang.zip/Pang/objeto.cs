﻿
class Objeto
{
    public void Mover()
    {

    }

    public void Desaparecer()
    {

    }
}

