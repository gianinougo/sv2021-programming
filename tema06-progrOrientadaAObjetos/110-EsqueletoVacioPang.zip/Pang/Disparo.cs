﻿
class Disparo
{
    static void Mover()
    {

    }

    public void Desaparecer()
    {

    }
}

