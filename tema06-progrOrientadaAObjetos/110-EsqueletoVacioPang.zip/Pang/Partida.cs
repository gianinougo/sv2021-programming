﻿
class Partida
{
    public void Lanzar()
    {

    }

    private void ComprobarTeclas()
    {

    }

    public void MoverElementos()
    {

    }

    public void ComprobarColisiones()
    {

    }

    public void DibujarElementos()
    {
        
    }
}

