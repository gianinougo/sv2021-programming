﻿// JOSE CUBÍ ALBERT
/* 110. Implementa las clases que has diseñado en tu diagrama (obviamente, es 
 * sólo un esqueleto de juego, con funciones vacías, y que no será jugable 
 * aún). Deberás entregar todo el proyecto de Visual Studio.
 */
using System;

namespace Pang
{
    class Pang
    {
        static void Main()
        {
        }
    }
}