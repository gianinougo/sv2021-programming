﻿
class Bienvenida
{
    public void Lanzar()
    {

    }
}

