﻿
class Marcador
{
    public int tiempo, vida, puntuacion;

    public void MostrarTiempo()
    {

    }

    public void MostrarVidas()
    {

    }

    public void MostrarPuntuacion()
    {

    }
}

