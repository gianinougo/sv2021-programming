﻿
class Ladrillo
{
    public void Desaparecer(int x, int y)
    {

    }
}

