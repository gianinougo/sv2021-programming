﻿
class Bola
{
    public void MoverArribaDerecha()
    {

    }
    public void MoverArribaIzquiera()
    {

    }
    public void MoverAbajoDerecha()
    {

    }
    public void MoverAbajoIzquierda()
    {

    }
    public void Dividir()
    {

    }

    public void Desaparecer()
    {

    }
}

