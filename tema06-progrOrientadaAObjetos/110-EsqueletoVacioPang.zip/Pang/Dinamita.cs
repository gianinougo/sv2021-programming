﻿
class Dinamita
{
    public void ExplotarBolas()
    {

    }
}

