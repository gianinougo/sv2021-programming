﻿
class VidaExtra
{
    public void AumentarVida()
    {

    }
}

