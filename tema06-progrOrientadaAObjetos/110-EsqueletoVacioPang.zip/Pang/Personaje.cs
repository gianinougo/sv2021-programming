﻿
class Personaje
{
    public void MoverDerecha()
    {

    }

    public void MoverIzquierda()
    {

    }

    public void Disparar()
    {

    }
}

