﻿
class Reloj
{
    public void AumentarTiempo()
    {

    }
}

