﻿
class Arma
{
    public void CambiarArma()
    {

    }
}

