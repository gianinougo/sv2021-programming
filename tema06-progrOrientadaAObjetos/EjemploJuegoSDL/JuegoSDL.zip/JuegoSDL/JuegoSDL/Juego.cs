﻿
namespace JuegoSDL
{
    class Juego
    {
        static void Main(string[] args)
        {
            // Variables que usaremos: una imagen y un tipo de letra
            Sprite personaje;
            Fuente fuente18;
            int x = 800, y = 500;
            int velocidad = 5;

            // Inicializo modo grafico 1280x720 puntos, 24 bits de color
            Hardware.Inicializar(1280, 720, 24);

            // Cargo imagenes y tipos de letra
            personaje = new Sprite("datos/personaje.png");
            fuente18 = new Fuente("datos/FreeSansBold.ttf", 18);

            // Bucle de juego
            bool terminado = false;
            do
            {
                // Actualizar pantalla
                Hardware.BorrarPantallaOculta();

                personaje.MoverA(x, y);
                personaje.Dibujar();

                Hardware.EscribirTextoOculta(
                    "Pulsa ESC para salir",
                    300, 500,  // Coordenadas
                    0xAA, 0xAA, 0xAA, // Color: gris claro
                    fuente18); // Tipo de letra

                Hardware.VisualizarOculta();

                // Comprobar acciones del usuario
                if (Hardware.TeclaPulsada(Hardware.TECLA_DER))
                    x += velocidad;
                // ...

                if (Hardware.TeclaPulsada(Hardware.TECLA_ESC))
                    terminado = true;

                //Mover enemigos, fondo, etc 
                // TO DO

                // Comprobar colisiones y aplicar la lógica de juego
                // TO DO

                // Pausa (20 ms = 50 fps)
                Hardware.Pausa(20);
            }
            while (!terminado);

        }
    }
}
