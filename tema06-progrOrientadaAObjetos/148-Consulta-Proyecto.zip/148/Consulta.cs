﻿// Ejercicio recomendado 148
// Javier (...)

using System;

class Consulta
{
    const int MAX_PACIENTES = 100;
    const int MAX_VISITAS = 100;
    const int MAX_MEDICOS = 100;
    private static void Ejecutar()
    {
        Medico m1 = new Medico("Perez García, Manuel", 1, "Neurología");
        Medico m2 = new Medico("Gómez Jurado, Ramón", 2, "Traumatología");
        Medico[] medicos = new Medico[MAX_MEDICOS];
        medicos[0] = m1;
        medicos[1] = m2;
        int numMedicos = 2;
        Enfermero e1 = new Enfermero("Corona Lara, Beatriz", 3);
        Paciente[] pacientes = new Paciente[MAX_PACIENTES];        
        Visita[] visitas = new Visita[MAX_VISITAS];
        int numPacientes = 0, numVisitas = 0;
        string opcion;
        bool salir = false;

        do
        {
            MostrarMenu();
            opcion = Console.ReadLine().ToUpper();

            switch(opcion)
            {
                case "1": AnyadirPaciente(ref pacientes, ref numPacientes); break;
                case "2": BuscarPacientes(pacientes, numPacientes); break;
                case "3": 
                    AnyadirVisita(ref visitas, ref numVisitas, pacientes, 
                        numPacientes, medicos, numMedicos); 
                    break;
                case "4": VerVisitas(visitas, numVisitas); break;
                case "S":
                    Console.WriteLine("No se pueden guardar los datos y se " +
                        "perderán. Hasta la próxima!");
                    salir = true;
                    break;
                default:
                    Console.WriteLine("Opción incorrecta");
                    break;
            }
        }
        while (!salir);
    }

    private static void VerVisitas(Visita[] visitas, int numVisitas)
    {
        if (numVisitas > 0)
        {
            for (int i = 0; i < numVisitas; i++)
                Console.WriteLine(visitas[i]);
        }
        else
            Console.WriteLine("No hay visitas");
    }

    private static int ExistePersona(Persona[] personas, int numPersonas,
        int codigoPersona)
    {
        bool pacienteCorrecto = false;
        int persona = - 1;

        if (numPersonas > 0)
        {
            int i = 0;

            while (!pacienteCorrecto && i < numPersonas)
            {
                if (personas[i].Codigo == codigoPersona)
                {
                    pacienteCorrecto = true;
                    persona = i;
                }

                i++;
            }
        }

        return persona;
    }

    private static void AnyadirVisita(ref Visita[] visitas, ref int numVisitas, 
        Paciente[] pacientes, int numPacientes, Medico[] medicos, int numMedicos)
    {
        if (numVisitas < MAX_VISITAS)
        {
            string tipoVisita = PedirDato("Tipo visita: (1) Urgencia - " +
                "(2) Planificada");
            int codigoPaciente = Convert.ToInt32(PedirDato("Código del paciente"));
            int codigoMedico = Convert.ToInt32(PedirDato("Código del médico"));
            string motivoVisita = PedirDato("Motivo de la visita");
            string diagnostico = PedirDato("Diagnóstico");

            int numPaciente = ExistePersona(pacientes, numPacientes,
                codigoPaciente);
            int numMedico = ExistePersona(medicos, numMedicos, codigoMedico);

            if (numPaciente >= 0 && numPaciente >= 0)
            {
                if (tipoVisita == "1")
                {
                    string visitaPosterior = PedirDato("Necesita visita posterior? " +
                        "(1) Sí - (2) No");
                    bool necesitaVisitaPosterior = visitaPosterior == "1";

                    visitas[numVisitas] = new Urgencia(pacientes[numPaciente],
                        medicos[numMedico], DateTime.Now, motivoVisita,
                        diagnostico, necesitaVisitaPosterior);
                }
                else
                    visitas[numVisitas] = new Planificada(pacientes[numPaciente],
                        medicos[numMedico], DateTime.Now, motivoVisita,
                        diagnostico);

                numVisitas++;
            }
            else
            {
                Console.WriteLine("El código de paciente o médico " +
                    "introducidos no existe");
            }

        }
        else
            Console.WriteLine("No caben más visitas");
    }

    private static void BuscarPacientes(Paciente[] pacientes, int numPacientes)
    {
        if (numPacientes > 0)
        {
            bool encontrado = false;

            Console.WriteLine("Introduce el texto de búsqueda de pacientes:");
            string busqueda = PedirDato("Texto de la búsqueda").ToLower();

            for (int i = 0; i < numPacientes; i++)
            {
                if (pacientes[i].ToString().ToLower().Contains(busqueda))
                {
                    Console.WriteLine(pacientes[i]);
                    encontrado = true;
                }
            }

            if (!encontrado)
                Console.WriteLine("No se han encontrado pacientes con los " +
                    "datos de búsqueda introducidos");
        }
        else
            Console.WriteLine("No hay pacientes");
    }

    private static void AnyadirPaciente(ref Paciente[] pacientes,
        ref int numPacientes)
    {
        if (numPacientes < MAX_PACIENTES)
        {
            Console.WriteLine("Introduce los datos del paciente:");
            string apellidos = PedirDato("Apellidos");
            string nombre = PedirDato("Nombre");
            apellidos += ", " + nombre;

            int codigo = Convert.ToInt32(PedirDato("Código"));

            if (ExistePersona(pacientes, numPacientes, codigo) < 0)
            {
                pacientes[numPacientes] = new Paciente(apellidos, codigo);
                numPacientes++;
            }
            else
                Console.WriteLine("Error: el código de paciente ya existe");
        }
        else
            Console.WriteLine("No caben más pacientes");
    }

    private static string PedirDato(string aviso)
    {
        Console.Write(aviso + ": ");
        return Console.ReadLine();
    }

    private static void MostrarMenu()
    {
        Console.WriteLine();
        Console.WriteLine("1. Añadir paciente");
        Console.WriteLine("2. Buscar pacientes");
        Console.WriteLine("3. Añadir visita");
        Console.WriteLine("4. Ver todas las visitas");
        Console.WriteLine("S. Salir");
        Console.WriteLine();
    }

    public static void Main()
    {
        Ejecutar();
    }
}
