﻿// Ejercicio recomendado 148
// Javier (...)

abstract class Persona
{
    public string Nombre { get; set; }
    public int Codigo { get; set; }


    public Persona(string nombre, int codigo)
    {
        Nombre = nombre;
        Codigo = codigo;
    }

    public override string ToString()
    {
        return Codigo + ", " + Nombre;
    }
}

