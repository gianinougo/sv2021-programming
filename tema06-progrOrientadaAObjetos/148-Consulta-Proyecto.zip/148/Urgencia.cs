﻿// Ejercicio recomendado 148
// Javier (...)

using System;

class Urgencia : Visita
{
    public bool NecesitaVisitaPosterior { get; set; }

    public Urgencia(Paciente paciente, Medico medico, DateTime fechaVisita,
        string motivoVisita, string diagnostico, bool necesitaVisitaPosterior)
        :base(paciente, medico, fechaVisita, motivoVisita, diagnostico)
    {
        NecesitaVisitaPosterior = necesitaVisitaPosterior;
    }

    public override string ToString()
    {
        string texto = "Urgencia - " + base.ToString();
        if (NecesitaVisitaPosterior)
            texto += " (P)";

        return texto;
    }
}

