﻿// Ejercicio recomendado 148
// Javier (...)

class Medico : Persona
{
    public string Especialidad { get; set; }

    public Medico(string nombre, int codigo)
        :base(nombre, codigo)
    {
        Especialidad = "Medicina general";
    }

    public Medico(string nombre, int codigo, string especialidad)
        :base(nombre, codigo)
    {
        Especialidad = especialidad;
    }

    public override string ToString()
    {
        return base.ToString() + ", " + Especialidad;
    }
}