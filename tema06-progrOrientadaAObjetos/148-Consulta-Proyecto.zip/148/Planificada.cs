﻿// Ejercicio recomendado 148
// Javier (...)

using System;

class Planificada : Visita
{
    public Planificada(Paciente paciente, Medico medico, DateTime fechaVisita,
        string motivoVisita, string diagnostico)
        : base(paciente, medico, fechaVisita, motivoVisita, diagnostico)
    { 
    }

    public override string ToString()
    {
        return "Planificada - " + base.ToString();
    }
}

