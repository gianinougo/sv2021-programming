﻿// Ejercicio recomendado 148
// Javier (...)

class Paciente : Persona
{
    public Paciente(string nombre, int codigo)
        :base(nombre, codigo)
    { 
    }
}

