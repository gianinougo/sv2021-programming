﻿// Ejercicio recomendado 148
// Javier (...)

class Enfermero : Persona
{
    public Enfermero(string nombre, int codigo)
        :base (nombre, codigo)
    { 
    }
}

