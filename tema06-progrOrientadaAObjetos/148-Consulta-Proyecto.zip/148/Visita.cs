﻿// Ejercicio recomendado 148
// Javier (...)

using System;

abstract class Visita
{
    public Paciente P { get; set; }
    public Medico M { get; set; }
    public DateTime FechaVisita { get; }
    public string MotivoVisita { get; set; }
    public string Diagnostico { get; set; }

    public Visita(Paciente paciente, Medico medico, DateTime fechaVisita, 
        string motivoVisita, string diagnostico)
    {
        P = paciente;
        M = medico;
        FechaVisita = fechaVisita;
        MotivoVisita = motivoVisita;
        Diagnostico = diagnostico;
    }

    public override string ToString()
    {
        return P.Nombre + " - " + M.Nombre + " - " + 
            FechaVisita + " - " + MotivoVisita + " - " + Diagnostico;
    }
}
