﻿/* Juan Manuel (...), retoques por Nacho */

/*
Ejercicio 103 Crea una nueva versión del ejercicio 102, en la que cada clase
esté en un fichero independiente, empleando Visual Studio (o alguna herramienta
similar). Deberás entregar todo el proyecto de Visual Studio, comprimido en un
fichero ZIP.
*/

using System;

class PruebaDeSprite
{
    static void Main()
    {
        SpriteTexto s = new SpriteTexto();

        s.SetX(40);
        s.SetY(12);
        s.SetCaracter('A');
        s.Dibujar();
        
        Console.ReadLine();
        s.MoverDerecha();
        s.Dibujar();
        
        Console.ReadLine();
        s.MoverDerecha();
        s.Dibujar();
        
        Console.ReadLine();
        s.MoverDerecha();
        s.Dibujar();
        
        Console.ReadLine();
    }
}
