﻿namespace JuegoSDL
{
    class Jugador : Sprite
    {
        public Jugador()
            : base("datos/personaje.png")
        {
            SetAnchoAlto(48, 45);
        }
    }
}
