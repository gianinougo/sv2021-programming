﻿//112.Rocio (...)

class PruebaDeRecuadro
{
    static void Main()
    {   
        Recuadro prueba = new Recuadro(1, 4, 8, 10, '*');
        prueba.Dibujar();
        
        Recuadro prueba2 = new Recuadro(20, 10, 20, 5, '+');
        prueba2.Dibujar();
    }
}

